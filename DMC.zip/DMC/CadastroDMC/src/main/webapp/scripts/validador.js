/**
 * 
 */
  function validar(){
	let nome = frmCadastro.nome.value;
	let nome = frmCadastro.cargo.value;
	let nome = frmCadastro.distrito.value;
	let nome = frmCadastro.fone.value;
	if (nome === ""){
		alert("Campo nome obrigatório");
		frmContato.nome.focus();
		}	
	else
	if (cargo === ""){
		alert("Campo cargo obrigatório");
		frmContato.cargo.focus();
		}	
	else
	if (distrito === ""){
		alert("Campo distrito obrigatório");
		frmContato.distrito.focus();
		}	
	else
	if (fone === ""){
		alert("Campo fone obrigatório");
		frmContato.fone.focus();
		}
	else
		document.forms["frmCadastro"].submit();	
		
	
}