package model;

import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class DAO {
	// Parametros de conex�o
	private String driver="com.mysql.cj.jdbc.Driver";
	private String url= "jdbc:mysql://127.0.0.1:3306/dbdmc?useTimezone=true&serverTimezone=UTC";
	private String user="root";
	private String password="";
	
	//Conex�o
	private Connection conectar() {
		Connection con = null;
		try {
			Class.forName(driver);
			con =DriverManager.getConnection(url, user, password);
			return con;
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
			return null;
		}
	}
	
	
	public void inserirContato(JavaBeans contato) {
		String SQLinsert = "insert into membros(nome,cargo,distrito,fone,email) values (?,?,?,?,?);";
		
		try {
			Connection con = conectar();
			// Preparar a query
			PreparedStatement pst = con.prepareStatement(SQLinsert);
			
			// Substituir as ?
			pst.setString(1, contato.getNome());
			pst.setString(2, contato.getCargo());
			pst.setString(3, contato.getDistrito());
			pst.setString(4, contato.getFone());
			pst.setString(5, contato.getEmail());
			
			
			System.out.println(pst);
			
			//Executar SQL
			pst.executeUpdate();
			
			//Encerrar a conex�o
			con.close();
			
			
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
		}
		
	}
	
	//CRUD READ
	
	public ArrayList<JavaBeans> listaContatos(){
		ArrayList<JavaBeans> contatos = new ArrayList<JavaBeans>();
		String sqlRead = "select * from membros order by nome";
		
		try {
			Connection con = conectar();
			//preparar a query
			PreparedStatement pst = con.prepareStatement(sqlRead);
			ResultSet rs = pst.executeQuery();
			while (rs.next() ) {
				 String idcon = rs.getString(1);
				 String nome = rs.getString(2);
				 String cargo = rs.getString(3);
				 String distrito = rs.getString(4);
				 String fone = rs.getString(5);
				 String email = rs.getString(6);
				 
				 //Enviando a matriz
				 contatos.add(new JavaBeans(idcon,nome,cargo,distrito,fone,email));
			}
			con.close();
			return contatos;
		} catch (Exception e) {
			System.out.println(e);
			return null;
		}
	}
	
	//CRUD SELECT
	
	public void selecionarContato(JavaBeans contato) {
		String sqlSelect = "select * from membros where idcon=?";
		try {
			Connection con = conectar();
			PreparedStatement pst = con.prepareStatement(sqlSelect);
			pst.setString(1, contato.getIdcon());
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				contato.setIdcon(rs.getString(1));
				contato.setNome(rs.getString(2));
				contato.setCargo(rs.getString(3));
				contato.setDistrito(rs.getString(4));
				contato.setFone(rs.getString(5));
				contato.setEmail(rs.getString(6));
			}
			con.close();
		}catch (Exception e) {
			System.out.println(e);
		}
			
		}
	
	
public void alterarContato(JavaBeans contato) {
	String sqlUpdate = "update membros set nome=?,cargo=?,distrito=?,fone=?,email=? where idcon=?";
	try {
		Connection con = conectar();
		PreparedStatement pst = con.prepareStatement(sqlUpdate);
			pst.setString(1, contato.getNome());
			pst.setString(2, contato.getCargo());
			pst.setString(3, contato.getDistrito());
			pst.setString(4, contato.getFone());
			pst.setString(5, contato.getEmail());
		
	
		pst.executeUpdate();
		con.close();
	} catch (Exception e) {
		System.out.println(e);
	}
}
}
	/*
	public void testeConexao() {
		try {
			Connection con=conectar();
			System.out.println(con);
			con.close();
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
		}
	}*/
	
	
	
	
	
	
	
	
	

