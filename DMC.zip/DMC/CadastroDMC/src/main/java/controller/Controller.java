package controller;

import java.io.IOException;

import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import model.DAO;
import model.JavaBeans;
/**
 * Servlet implementation class Controller
 */
@WebServlet(urlPatterns = {"/Controller","/main","/inserir","/select","/update","/delete"})
public class Controller extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	DAO dao = new DAO();
	JavaBeans contato = new JavaBeans();
	

    /**
     * Default constructor. 
     */
    public Controller() {
    	super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		//Teste Conex�o
		//DAO dao = new DAO();
		//dao.testeConexao();
		String action = request.getServletPath();
		System.out.println(action);
		if (action.equals("/main")){
			contatos(request, response);
		} else if (action.equals("/insert")) {
			novoContato(request,response);
		} else if (action.equals("/select")) {
			System.out.println("aten��o");
			listarContato(request,response);
		}	else if (action.equals("/update")) {
				editarContato(request,response);
			} else if (action.equals("/delete")) {
				//removerContato(request,response);
			} else	
				response.sendRedirect("index.html");
				
		
	}
	
	protected void contatos(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//response.sendRedirect("cadastro.jsp");
		ArrayList<JavaBeans> lista = dao.listaContatos();
		
		//System.out.println(lista.get(1).getIdcon());
		//System.out.println(lista.get(1).getNome());
		//System.out.println(lista.get(1).getCargo());
		//System.out.println(lista.get(1).getDistrito());
		//System.out.println(lista.get(1).getFone());
		//System.out.println(lista.get(1).getEmail());
		
		request.setAttribute("contatos", lista);
		RequestDispatcher rd = request.getRequestDispatcher("cadastro.jsp");
		rd.forward(request, response);
		
	}
	
	protected void novoContato(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//System.out.println(request.getParameter("nome"));
		//System.out.println(request.getParameter("fone"));
		//System.out.println(request.getParameter("email"));
		
		this.contato.setNome(request.getParameter("nome"));
		this.contato.setCargo(request.getParameter("cargo"));
		this.contato.setDistrito(request.getParameter("distrito"));
		this.contato.setFone(request.getParameter("fone"));
		this.contato.setEmail(request.getParameter("email"));
		//"C:/java/testeimagem.png"
		
		dao.inserirContato(contato);
		
		response.sendRedirect("main");
		
	}
	
	protected void listarContato(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String idcon = request.getParameter("idcon");
		System.out.println(idcon);
		this.dao.selecionarContato(contato);
		request.setAttribute("idcon", contato.getIdcon());
		request.setAttribute("nome", contato.getNome());
		request.setAttribute("cargo", contato.getCargo());
		request.setAttribute("distrito", contato.getDistrito());
		request.setAttribute("fone", contato.getFone());
		request.setAttribute("email", contato.getEmail());
		RequestDispatcher rd = request.getRequestDispatcher("editar.jsp");
		rd.forward(request, response);
	}
	protected void editarContato(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.contato.setIdcon(request.getParameter("Id"));
		this.contato.setNome(request.getParameter("nome"));
		this.contato.setCargo(request.getParameter("cargo"));
		this.contato.setDistrito(request.getParameter("distrito"));
		this.contato.setFone(request.getParameter("fone"));
		this.contato.setEmail(request.getParameter("email"));
		this.dao.alterarContato(this.contato);
		response.sendRedirect("main");
	}
	}

