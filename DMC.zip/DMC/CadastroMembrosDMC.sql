create database dbdmc;
use dbdmc;
show databases;

create table membros
(
	idcon int primary key auto_increment,
    nome varchar(50) not null,
    cargo varchar(50) not null,
    distrito varchar(50) not null,
    fone varchar(15) not null,
    email varchar(50)
);

show tables;
describe membros;


select*from membros;


